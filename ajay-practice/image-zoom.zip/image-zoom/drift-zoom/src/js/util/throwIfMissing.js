export default function throwIfMissing() {
  throw new Error("Missing parameter");
}
