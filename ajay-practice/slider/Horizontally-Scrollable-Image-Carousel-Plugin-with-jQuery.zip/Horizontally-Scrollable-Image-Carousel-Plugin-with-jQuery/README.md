jQueryScrollableCarousel
========================

Horizontally Scrollable Carousel

By hovering an image, it displays a customizable overlay appearing from the entrance direction of the cursor.

It scrolls by keyboard, by mouse wheel and by dragging the sroll bar.

This carousel requires:

-jQuery 1.11.0 +

-Bootstrap 3.1.1

-modernizr-2.6.2-respond-1.1.0

-Desandro's imagesLoaded PACKAGED v3.0.4

-Brandon Aaron's jquery-mousewheel

-Malihu's jquery custom scrollbars plugin

-Codrop's jquery.hoverdir.js v1.1.0 (modified)


All required scripts are included in js/plugins.js

There are 4 categories available:

category1, category2, category3 and category4

If you need to style category colours, you can do so in css.css.

If you need to change category names please declare them in js/plugins.js in line 35 col 1571.
